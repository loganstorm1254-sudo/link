﻿Beacon Console Bridge (Windows) — fixed bot launch
==================================================

1. Unzip. Keep files together.
2. Double-click BeaconConsoleBridge.exe
3. Enter Vercel URL, username, password
4. Enter path to your smmod FOLDER (contains smmod.py)
   Example: C:\Users\user\Documents\smmod
5. Leave command as smmod.py (or just press Enter)

The bridge now:
- Uses your real system Python (not a broken py+pipe launch)
- Kills old smmod.py processes before starting (fixes offline / double login)
- Wipes the website console logs on every restart

Close this window to stop the bot.
