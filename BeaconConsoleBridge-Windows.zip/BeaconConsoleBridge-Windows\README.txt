﻿Beacon Console Bridge (Windows)
================================

1. Unzip. Keep files together.
2. Double-click BeaconConsoleBridge.exe
3. Enter Vercel URL, username, password
4. Enter path to your smmod FOLDER (the folder that contains smmod.py)
5. Command: py smmod.py (runs inside that folder)

Website is READ-ONLY.
