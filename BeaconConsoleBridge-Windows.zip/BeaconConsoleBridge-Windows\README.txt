﻿Beacon Console Bridge — Start/Stop from website
================================================
Keep this window open. Website Start/Stop controls smmod.
Ctrl+C = stop smmod only. Type start or use website Start to run again.
