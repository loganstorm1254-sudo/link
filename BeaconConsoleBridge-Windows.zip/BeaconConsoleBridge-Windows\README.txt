﻿Beacon Console Bridge
=====================

Ctrl+C  = stop smmod only (bridge stays running)
start   = run smmod again
quit    = exit bridge

1. Unzip, run BeaconConsoleBridge.exe
2. Enter Vercel URL, username, password, smmod folder
